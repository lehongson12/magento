<?php

$installer = $this;

$installer->startSetup();

//$installer->run("");

$installer->endSetup(); 